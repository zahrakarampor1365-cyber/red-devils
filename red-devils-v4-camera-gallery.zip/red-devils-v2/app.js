const $ = (id) => document.getElementById(id);
const STORAGE_SETTINGS = "reddevils.settings.v3";
const STORAGE_CHATS = "reddevils.chats.v3";
const GROQ_URL = "https://api.groq.com/openai/v1";
const GROQ_MODEL = "openai/gpt-oss-20b";
let chats = JSON.parse(localStorage.getItem(STORAGE_CHATS) || "[]");
let currentChatId = null;
let busy = false;
let selectedImage = null;

function updateConnection(){const online=navigator.onLine;const el=$("connectionStatus"),dot=$("connectionDot");if(el)el.textContent=online?"آنلاین":"آفلاین";if(dot){dot.style.background=online?"#d8d8d8":"#777";dot.title=online?"اتصال اینترنت برقرار است":"اینترنت قطع است";}}
window.addEventListener("online",updateConnection);window.addEventListener("offline",updateConnection);updateConnection();
function offlineReply(q){const t=q.toLowerCase();if(/سلام|درود|hello/.test(t))return "سلام! 👋 الان آفلاین هستم. می‌توانی گفتگوهای قبلی را ببینی؛ برای پاسخ هوشمند کامل باید اینترنت وصل شود.";if(/اسم|نام/.test(t))return "من RED DEMONS هستم؛ دستیار فارسی تو. در حال حاضر اتصال اینترنت ندارم.";if(/کمک|راهنما/.test(t))return "در حالت آفلاین می‌توانی پیام‌ها را بنویسی و تاریخچه را ببینی. برای پاسخ‌گویی هوش مصنوعی، اینترنت را وصل کن.";return "الان اینترنت در دسترس نیست؛ پیام تو ذخیره شد. برای دریافت پاسخ دقیق از هوش مصنوعی، پس از اتصال اینترنت دوباره پیام را ارسال کن. در این حالت فقط پاسخ‌های ساده آفلاین ارائه می‌دهم.";}
function getSettings(){try{return JSON.parse(localStorage.getItem(STORAGE_SETTINGS)||"{}")}catch{return {}}}
function saveSettings(s){localStorage.setItem(STORAGE_SETTINGS,JSON.stringify(s));}
function newChat(){const c={id:Date.now().toString(),title:"گفت‌وگوی جدید",messages:[],updated:Date.now()};chats.unshift(c);currentChatId=c.id;persist();render();}
function currentChat(){return chats.find(c=>c.id===currentChatId)}
function persist(){localStorage.setItem(STORAGE_CHATS,JSON.stringify(chats));}
function escapeText(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function render(){
  const c=currentChat();$("messages").innerHTML="";
  if(!c||!c.messages.length){$("messages").innerHTML=`<div class="welcome" id="welcome"><div class="welcome-emblem">☠</div><h1>به شیاطین سرخ خوش آمدی</h1><p>هر سؤالی داری بنویس؛ من آماده‌ام کمکت کنم.</p><div class="suggestions"><button class="suggestion">برای من یک برنامه یادگیری طراحی کن</button><button class="suggestion">یک ایده خلاقانه پیشنهاد بده</button><button class="suggestion">این موضوع را ساده توضیح بده</button></div></div>`;document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>{ $("messageInput").value=b.textContent;sendMessage();});}
  else c.messages.forEach(m=>appendMessage(m.role,m.content,m.image));
  $("historyList").innerHTML=chats.map(x=>`<button class="history-item ${x.id===currentChatId?"active":""}" data-id="${x.id}">${escapeText(x.title)}</button>`).join("");
  document.querySelectorAll(".history-item").forEach(b=>b.onclick=()=>{currentChatId=b.dataset.id;render();});
  const s=getSettings();$("modelBadge").textContent=s.model||"مدل تنظیم نشده";
}
function appendMessage(role,content,image){const row=document.createElement("div");row.className=`message ${role==="user"?"user":"assistant"}`;const avatar=role==="user"?"شما":"♛";const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content||"";if(image){const img=document.createElement("img");img.className="message-photo";img.src=image;img.alt="عکس ارسال‌شده";bubble.appendChild(img);}row.innerHTML=`<div class="avatar">${avatar}</div>`;row.appendChild(bubble);$("messages").appendChild(row);$("messages").scrollTop=$("messages").scrollHeight;}
function openSettings(){const s=getSettings();$("apiKey").value=s.apiKey||"";$("apiUrl").value=s.baseUrl||GROQ_URL;$("modelName").value=s.model||GROQ_MODEL;$("settingsStatus").textContent="";$("settingsModal").classList.remove("hidden");}
function closeSettings(){$("settingsModal").classList.add("hidden");}
$("settingsBtn").onclick=openSettings;$("closeSettingsBtn").onclick=closeSettings;$("modalBackdrop").onclick=closeSettings;
$("newChatBtn").onclick=newChat;$("sidebarNewChat").onclick=newChat;
$("groqPreset").onclick=()=>{$("apiUrl").value=GROQ_URL;$("modelName").value=GROQ_MODEL;$("settingsStatus").textContent="تنظیمات پیشنهادی Groq قرار داده شد؛ کلید خودت را وارد کن.";};
$("toggleKeyBtn").onclick=()=>{$("apiKey").type=$("apiKey").type==="password"?"text":"password";$("toggleKeyBtn").textContent=$("apiKey").type==="password"?"نمایش":"مخفی"};
$("clearSettingsBtn").onclick=()=>{localStorage.removeItem(STORAGE_SETTINGS);$("apiKey").value="";$("apiUrl").value=GROQ_URL;$("modelName").value=GROQ_MODEL;$("settingsStatus").textContent="تنظیمات پاک شد.";render();};
$("settingsForm").onsubmit=e=>{e.preventDefault();const s={apiKey:$("apiKey").value.trim(),baseUrl:$("apiUrl").value.trim().replace(/\/+$/,""),model:$("modelName").value.trim()};if(!s.apiKey||!s.baseUrl||!s.model){$("settingsStatus").textContent="لطفاً هر سه فیلد را کامل کن.";return;}if(!/^https:\/\//i.test(s.baseUrl)){$("settingsStatus").textContent="آدرس API باید با https:// شروع شود.";return;}saveSettings(s);$("settingsStatus").textContent="تنظیمات با موفقیت ذخیره شد.";render();setTimeout(closeSettings,650);};
function clearSelectedImage() {
  selectedImage = null;
  $("cameraInput").value = "";
  $("galleryInput").value = "";
  $("imagePreview").classList.add("hidden");
  $("previewImage").removeAttribute("src");
}
function prepareImage(file) {
  if (!file || !file.type.startsWith("image/")) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 1280, scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale); canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      selectedImage = canvas.toDataURL("image/jpeg", 0.78);
      $("previewImage").src = selectedImage;
      $("imagePreview").classList.remove("hidden");
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}
$("cameraBtn").onclick = () => $("cameraInput").click();
$("galleryBtn").onclick = () => $("galleryInput").click();
$("cameraInput").onchange = e => prepareImage(e.target.files[0]);
$("galleryInput").onchange = e => prepareImage(e.target.files[0]);
$("removeImageBtn").onclick = clearSelectedImage;

async function sendMessage(){
  if(busy)return;
  const input=$("messageInput"),text=input.value.trim(),image=selectedImage;
  if(!text&&!image)return;
  const s=getSettings();
  if(!currentChat())newChat();
  const c=currentChat();
  c.messages.push({role:"user",content:text||"لطفاً این عکس را بررسی کن.",...(image?{image}: {})});
  if(c.messages.length===1)c.title=(text||"عکس ارسالی").slice(0,34);
  c.updated=Date.now();input.value="";clearSelectedImage();persist();render();
  const typing=document.createElement("div");typing.className="typing";typing.textContent="شیاطین سرخ در حال فکر کردن است…";$("messages").appendChild(typing);$("messages").scrollTop=$("messages").scrollHeight;
  busy=true;$("sendBtn").disabled=true;
  if(!navigator.onLine){const answer=offlineReply(text||"عکس");c.messages.push({role:"assistant",content:answer+" عکس در تاریخچه همین دستگاه ذخیره شد، اما برای تحلیل عکس باید اینترنت وصل باشد."});persist();typing.remove();appendMessage("assistant",c.messages[c.messages.length-1].content);busy=false;$("sendBtn").disabled=false;return;}
  if(!s.apiKey||!s.baseUrl||!s.model){typing.remove();const msg="برای پاسخ هوشمند آنلاین، ابتدا تنظیمات Groq را کامل کن. پیام و عکس تو در تاریخچه ذخیره شد.";c.messages.push({role:"assistant",content:msg});persist();appendMessage("assistant",msg);busy=false;$("sendBtn").disabled=false;return;}
  try{
    const apiMessages=c.messages.map(m=>({role:m.role,content:m.image?[{type:"text",text:m.content||"این عکس را بررسی کن."},{type:"image_url",image_url:{url:m.image}}]:m.content}));
    const response=await fetch("/.netlify/functions/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apiKey:s.apiKey,baseUrl:s.baseUrl,model:s.model,messages:apiMessages})});
    const data=await response.json();if(!response.ok)throw new Error(data.error||"ارتباط با سرویس ناموفق بود.");
    const answer=data.reply||"پاسخی دریافت نشد.";c.messages.push({role:"assistant",content:answer});persist();typing.remove();appendMessage("assistant",answer);
  }catch(err){typing.remove();const msg="خطا: "+(err.message||"اتصال برقرار نشد.")+". برای تحلیل عکس، مدلی انتخاب کن که ورودی تصویری (Vision) را پشتیبانی کند.";c.messages.push({role:"assistant",content:msg});persist();appendMessage("assistant",msg);}
  finally{busy=false;$("sendBtn").disabled=false;}
}
$("chatForm").onsubmit=e=>{e.preventDefault();sendMessage();};
$("messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();}});
if(!chats.length)newChat();else{currentChatId=chats[0].id;render();}
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));