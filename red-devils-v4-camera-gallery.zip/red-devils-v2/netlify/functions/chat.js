exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "روش درخواست پشتیبانی نمی‌شود." });
  try {
    const body = JSON.parse(event.body || "{}");
    const apiKey = String(body.apiKey || "").trim();
    const baseUrl = String(body.baseUrl || "").trim().replace(/\/+$/, "");
    const model = String(body.model || "").trim();
    const messages = Array.isArray(body.messages) ? body.messages : [];
    if (!apiKey || !baseUrl || !model || !messages.length) return reply(400, { error: "کلید API، آدرس، مدل و پیام لازم است." });
    if (!/^https:\/\//i.test(baseUrl)) return reply(400, { error: "آدرس سرویس باید HTTPS باشد." });
    if (messages.length > 60) return reply(400, { error: "تعداد پیام‌ها بیش از حد مجاز است." });
    const endpoint = baseUrl.endsWith("/chat/completions") ? baseUrl : `${baseUrl}/chat/completions`;
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, temperature: 0.7 })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = data?.error?.message || data?.message || `خطای سرویس (${upstream.status})`;
      return reply(upstream.status, { error: detail });
    }
    const content = data?.choices?.[0]?.message?.content;
    const answer = Array.isArray(content) ? content.map(x => x.text || "").join("") : content;
    if (!answer) return reply(502, { error: "مدل پاسخ متنی برنگرداند." });
    return reply(200, { reply: answer });
  } catch (e) {
    return reply(500, { error: "خطای داخلی: " + (e.message || "نامشخص") });
  }
};
function reply(statusCode, payload) {
  return { statusCode, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }, body: JSON.stringify(payload) };
}